package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Food_Sells {

    @Getter @Setter
    private Food_Items food_items;

    @Getter @Setter
    private Shop shop;

    @Getter @Setter
    private int cost;

}
