package com.example.Project.dao;


import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class HOSRepository {

    @Autowired
    private JdbcTemplate template;

    public void createHOS(Head_of_Shop head) {
        String sql = "INSERT INTO Head_of_Shop VALUES(?,?)";
        template.update(sql,head.getEmployee().getEmp_id(),head.getShop().getShop_id());
    }

    public void updateHOS(Head_of_Shop head) {
        String sql = "UPDATE Head_of_Shop SET emp_id=? WHERE shop_id = ?";
        template.update(sql,head.getEmployee().getEmp_id(),head.getShop().getShop_id());
    }

    public List<Head_of_Shop> getAll() {
        String sql = "SELECT * FROM Head_of_Shop H, Shop S, Employee E,user U WHERE H.emp_id=E.emp_id and E.username=U.username and S.shop_id=H.shop_id";
        return template.query(sql, new RowMapper<Head_of_Shop>() {
            @Override
            public Head_of_Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Employee employee = (new BeanPropertyRowMapper<>(Employee.class)).mapRow(rs, rowNum);
                employee.setShop(shop);
                employee.setUser(user);
                Head_of_Shop head = (new BeanPropertyRowMapper<>(Head_of_Shop.class)).mapRow(rs, rowNum);
                head.setShop(shop);
                head.setEmployee(employee);
                return head;
            }
        });
    }

    public void DeleteShop(int id){
        String sql = "DELETE FROM Head_of_Shop WHERE shop_id=?";
        template.update(sql,id);
    }

}
