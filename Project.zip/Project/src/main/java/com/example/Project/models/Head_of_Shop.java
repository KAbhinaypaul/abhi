package com.example.Project.models;


import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Head_of_Shop {
    private Shop shop;
    private Employee employee;
}
