USE DBMS;
INSERT INTO Department values ( 'Food','1st Floor',0 );
INSERT INTO Department values ('Grocery','Ground Floor',0);
INSERT INTO Department values ('Clothes','2nd Floor',0);
INSERT INTO Department values('Movies','3rd Floor',0);