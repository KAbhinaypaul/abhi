package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Customer {

    @Getter @Setter
    private int Customer_id;

    @Getter @Setter
    private User user;
}
