package com.example.Project.controllers;


import com.example.Project.Services.SecurityService;
import com.example.Project.dao.*;
import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@Transactional

public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private HOSRepository hosRepository;

    @Autowired
    private  EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    public LocalDate d1 = LocalDate.of(0000,01,01);
    public LocalDate d2 = LocalDate.now();

    int shop_id=-1;


    @GetMapping("/admin/profile")
    public String get_Profile(Model model) {
        User user = securityService.findLoggedInUser();
        User user1 = userRepository.getUser(user.getUsername());
        model.addAttribute("user",user1);
        return "admin/profile.html";
    }
    @GetMapping("/admin/settings")
    public String profile_settings(Model model) {
        User user = new User();
        model.addAttribute("user",user);
        return "admin/settings.html";
    }

    @PostMapping("/admin/settings")
    public String profile_update(@ModelAttribute("user") User user,@RequestParam( name="date") String s){
        User user1 = securityService.findLoggedInUser();
        user.setPassword(user1.getPassword());
        user.setRole(user1.getRole());
        user.setUsername(user1.getUsername());
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.updateUser(user);
        return "redirect:/admin/profile";
    }

    @GetMapping("/admin/add_admin")
    public String add_admin(Model model){
        User user = new User();
        model.addAttribute(user);
        return "admin/add_admin.html";
    }

    @PostMapping("/admin/add_admin")
    public String new_admin(@ModelAttribute("user") User user,@RequestParam(name="date") String s) {
        user.setRole("Admin");
        user.setDateofBirth(LocalDate.parse(s)) ;
        userRepository.CreateUser(user);
        Admin admin = new Admin();
        admin.setUser(user);
        adminRepository.CreateAdmin(admin);
        return "redirect:/admin/profile";
    }

    @GetMapping("/admin/transactions")
    public String transactions(Model model) {
        List<Transaction> transactions;
        if(shop_id==-1)
            transactions = transactionRepository.getTransactionBetweenDates(d1,d2);
        else
            transactions = transactionRepository.getTransactionBetweenDatesInShop(d1,d2,shop_id);
        model.addAttribute("transactions", transactions);
        d1 = LocalDate.of(0000,01,01);
        d2 = LocalDate.now();
        shop_id = -1;
        List<Shop> shops = shopRepository.getAll();
        model.addAttribute("shops", shops);
        return "admin/transactions.html";
    }

    @PostMapping("/admin/transactions")
    public String transactionsBetweenDates(@RequestParam("from_date") String a, @RequestParam("to_date") String b, @RequestParam("shop") int id){
        if(a!="")
            d1 = LocalDate.parse(a);
        if(b!="")
            d2 = LocalDate.parse(b);
        if(id!=0)
            shop_id = id;
        return "redirect:/admin/transactions";
    }

    @GetMapping("/admin/shop")
    public String shops(Model model){
        List<Head_of_Shop> hos = hosRepository.getAll();
        model.addAttribute("hos", hos);
        return "admin/shop.html";
    }

    @GetMapping("/admin/add_shop")
    public String add_shop(Model model){
        Shop shop=new Shop();
        Department department = new Department();
        User user =new User();
        Employee employee=new Employee();
        model.addAttribute("shop",shop);
        model.addAttribute("user",user);
        model.addAttribute("employee",employee);
        model.addAttribute("department", department);
        return "admin/add_shop.html";
    }
    @PostMapping("/admin/add_shop")
    public String shop_details(@ModelAttribute("department") Department department, @ModelAttribute("shop") Shop shop, @ModelAttribute("user") User user,@ModelAttribute("employee") Employee employee,@RequestParam(name="date") String s,  Model model) {
        user.setRole("Head of Shop");
        user.setDateofBirth(LocalDate.parse(s));
        department = departmentRepository.getDepartment(department.getDeptName());
        System.out.println("7777");
        department.setNo_of_shops(department.getNo_of_shops()+1);
        departmentRepository.updateDepartment(department);
//        int index = shopRepository.getIndex().getShop_id()+1;
        System.out.println("6666");
//        shop.setShop_id(index);
        shop.setDepartment(department);
        userRepository.CreateUser(user);
        System.out.println("5555");
        shopRepository.CreateShop(shop);
        shop.setShop_id(shopRepository.getIndex().getShop_id());
        System.out.println("4444");
        employee.setShop(shop);
        employee.setUser(user);
        employeeRepository.createEmployee(employee);
        System.out.println("3333");
        employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        System.out.println("2222");
//        Head_of_Shop hos = new Head_of_Shop();
        model.addAttribute("shop", shop);
        model.addAttribute("employee",employee);
//        hos.setShop(shop);
//        hos.setEmployee(employee);
//        hosRepository.createHOS(hos);
//        System.out.println("1111");
        Head_of_Shop hos = new Head_of_Shop();
        hos.setEmployee(employee);
        hos.setShop(shop);
        System.out.println("-2-2-2-");
        hosRepository.createHOS(hos);
        System.out.println("?????");
        return "redirect:/admin/shop";
    }


    @GetMapping("/admin/delete_shop/{shop_id}")
    public String delete_shop(@PathVariable("shop_id") int id) {
        Department department = shopRepository.getShop(id).getDepartment();
        department.setNo_of_shops(department.getNo_of_shops()-1);
        departmentRepository.updateDepartment(department);

        List<Employee> employeeList = employeeRepository.getEmployeesbyShopid(id);
        ArrayList<User> user = new ArrayList<>();
        for(int i=0;i<employeeList.size();i++)
            user.add(employeeList.get(i).getUser());
        for(int i=0;i<user.size();i++)
            userRepository.deleteUser(user.get(i).getUsername());
        shopRepository.DeleteShop(id);
//        hosRepository.DeleteShop(id);
        return "redirect:/admin/shop";
    }
}
