package com.example.Project.dao;


import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Cloth_SellsRepository {

    @Autowired
    private JdbcTemplate template;

    public List<Cloth_Sells> getItems(int shop_id) {
        String sql="SELECT * FROM Cloth_Sells cs,Cloth_Items ci,Shop s WHERE s.shop_id=? and s.shop_id=cs.shop_id and cs.cloth_id=ci.item_id";
        return template.query(sql, new RowMapper<Cloth_Sells>() {
            @Override
            public Cloth_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Cloth_Items cloth_items=(new BeanPropertyRowMapper<>(Cloth_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Cloth_Sells cloth_sells=(new BeanPropertyRowMapper<>(Cloth_Sells.class)).mapRow(rs,rowNum);
                cloth_sells.setCloth_items(cloth_items);
                cloth_sells.setShop(shop);
                return cloth_sells;
            }
        }, shop_id);
    }
    public Cloth_Sells getItem(int item_id, int shop_id) {
        String sql="SELECT * FROM Cloth_Sells cs, Cloth_Items ci, Shop s WHERE s.shop_id=? and s.shop_id=cs.shop_id and cs.cloth_id=ci.item_id and cs.cloth_id=?";
        return template.queryForObject(sql, new RowMapper<Cloth_Sells>() {
            @Override
            public Cloth_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Cloth_Items cloth_items=(new BeanPropertyRowMapper<>(Cloth_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Cloth_Sells cloth_sells=(new BeanPropertyRowMapper<>(Cloth_Sells.class)).mapRow(rs,rowNum);
                cloth_sells.setCloth_items(cloth_items);
                cloth_sells.setShop(shop);
                return cloth_sells;
            }
        }, new Object[] { shop_id, item_id} );
    }
    public void updateCloth(Cloth_Sells c) {
        String sql = "UPDATE Cloth_Sells SET cost=?,pieces=? WHERE cloth_id=?";
        template.update(sql,c.getCost(),c.getPieces(),c.getCloth_items().getItem_id());
    }

    public void createSells(Cloth_Sells cloth_sells) {
        String sql ="INSERT INTO Cloth_Sells VALUES(?,?,?,?)";
        template.update(sql,cloth_sells.getCloth_items().getItem_id(),cloth_sells.getShop().getShop_id(),cloth_sells.getCost(),cloth_sells.getPieces());
    }

    public void DeleteItem(int item_id, int shop_id) {
        String sql = "DELETE FROM Cloth_Sells WHERE cloth_id=? and shop_id=?";
        template.update(sql, item_id, shop_id);
    }
}
