package com.example.Project.dao;

import com.example.Project.models.Cloth_Items;
import com.example.Project.models.Department;
import com.example.Project.models.Food_Items;
import com.example.Project.models.Grocery_Items;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Cloth_ItemsRepository {

    @Autowired
    private JdbcTemplate template;
    public Cloth_Items getItem(int id) {
        String sql="SELECT * FROM Cloth_Items WHERE item_id=?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<>(Cloth_Items.class), new Object[] { id });
    }

    public void createCloth_Item(Cloth_Items cloth_items) {
        String sql = "INSERT INTO Cloth_Items(size,type) VALUES(?,?)";
        template.update(sql,cloth_items.getSize(),cloth_items.getType());
    }

    public void deleteCloth_Item(int id) {
        String sql = "DELETE FROM Cloth_Items where item_id=?";
        template.update(sql,id);
    }

    public void updateCloth_Item(Cloth_Items cloth_items) {
        String sql = "UPDATE Cloth_Items SET size=?, type=? WHERE item_id=?";
        template.update(sql,cloth_items.getSize(),cloth_items.getType(),cloth_items.getItem_id());
    }

    public List<Cloth_Items> getAll() {
        String sql = "SELECT * FROM Cloth_Items";
        return template.query(sql, new BeanPropertyRowMapper<>(Cloth_Items.class));
    }
    public Cloth_Items  getIndex() {
        String sql = "SELECT * FROM Cloth_Items WHERE item_id=(SELECT MAX(item_id) FROM Cloth_Items)";
        return template.queryForObject(sql, new RowMapper<Cloth_Items>() {
            @Override
            public Cloth_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Cloth_Items cloth_items = (new BeanPropertyRowMapper<>(Cloth_Items.class)).mapRow(rs, rowNum);
                return cloth_items;
            }
        });
    }
    public List<Cloth_Items> getAllNotFromShop(int id) {
        String sql ="(SELECT * FROM Cloth_Items ci) EXCEPT (SELECT ci.Item_id,ci.size,ci.type FROM Cloth_Items ci, Cloth_Sells cs, Shop S WHERE ci.item_id=cs.cloth_id and S.shop_id=cs.shop_id and S.shop_id=?)";
        return template.query(sql, new RowMapper<Cloth_Items>() {
            @Override
            public Cloth_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Cloth_Items cloth_items = (new BeanPropertyRowMapper<>(Cloth_Items.class)).mapRow(rs, rowNum);
                return cloth_items;
            }
        },id);
    }

}
