package com.example.Project.dao;


import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Grocery_SellsRepository {

    @Autowired
    private JdbcTemplate template;

    public List<Grocery_Sells> getItems(int shop_id) {
        String sql="SELECT * FROM Grocery_Sells gs,Grocery_Items gi,Shop s WHERE s.shop_id=? and s.shop_id=gs.shop_id and gs.item_id=gi.item_id";
        return template.query(sql, new RowMapper<Grocery_Sells>() {
            @Override
            public Grocery_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Grocery_Items grocery_items=(new BeanPropertyRowMapper<>(Grocery_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Grocery_Sells grocery_sells=(new BeanPropertyRowMapper<>(Grocery_Sells.class)).mapRow(rs,rowNum);
                grocery_sells.setGrocery_items(grocery_items);
                grocery_sells.setShop(shop);
                return grocery_sells;
            }
        }, shop_id);
    }
    public Grocery_Sells getItem(int item_id, int shop_id) {
        String sql="SELECT * FROM Grocery_Sells gs, Grocery_Items gi, Shop s WHERE s.shop_id=? and s.shop_id=gs.shop_id and gs.item_id=gi.item_id and gs.item_id=?";
        return template.queryForObject(sql, new RowMapper<Grocery_Sells>() {
            @Override
            public Grocery_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Grocery_Items grocery_items=(new BeanPropertyRowMapper<>(Grocery_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Grocery_Sells grocery_sells=(new BeanPropertyRowMapper<>(Grocery_Sells.class)).mapRow(rs,rowNum);
                grocery_sells.setGrocery_items(grocery_items);
                grocery_sells.setShop(shop);
                return grocery_sells;
            }
        }, new Object[] { shop_id, item_id} );
    }

    public void updateGrocery(Grocery_Sells g) {
        String sql = "UPDATE Grocery_Sells SET Cost=?,availability=? WHERE item_id=?";
        template.update(sql,g.getCost(),g.getAvailability(),g.getGrocery_items().getItem_id());
    }
    public void createSells(Grocery_Sells grocery_sells) {
        String sql ="INSERT INTO Grocery_Sells VALUES(?,?,?,?)";
        template.update(sql,grocery_sells.getGrocery_items().getItem_id(),grocery_sells.getShop().getShop_id(),grocery_sells.getCost(),grocery_sells.getAvailability());
    }

    public void DeleteItem(int item_id, int shop_id) {
        String sql = "DELETE FROM Grocery_Sells WHERE Item_id=? and shop_id=?";
        template.update(sql,item_id,shop_id);
    }
}
