package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Shop {

    @Getter @Setter
    private int shop_id;

    @Getter @Setter
    private String shop_name;

    @Getter @Setter
    private Department department;

}
