package com.example.Project.config;

import com.example.Project.dao.UserRepository;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service

public class UserDetailsServiceImplements implements UserDetailsService {

    @Lazy
    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.getUser(username);
        if(user==null)
            throw new UsernameNotFoundException("Invalid username");
        return new MyUserDetails(user);
    }
}
