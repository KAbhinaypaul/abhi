package com.example.Project.dao;


import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@Repository
public class TransactionRepository {

    @Autowired
    private JdbcTemplate template;

    public void createTransaction(Transaction transaction){
        String sql = "INSERT INTO Transactions(customer_id,shop_id, Bill,t_date) VALUES(?,?,?,?)";
        template.update(sql,transaction.getCustomer_id(),transaction.getShop_id(),transaction.getBill(),transaction.getT_date());
    }

    public List<Transaction> getTransactionByCustomerId(int id){
        String sql ="SELECT * FROM Transactions T WHERE T.customer_id=?";
        return template.query(sql, new RowMapper<Transaction>() {
            @Override
            public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
//                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
//                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
//                customer.setUser(user);
//                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
//                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
//                shop.setDepartment(department);
                Transaction transaction = (new BeanPropertyRowMapper<>(Transaction.class)).mapRow(rs, rowNum);
//                transaction.setCustomer(customer);
//                transaction.setShop(shop);
                return transaction;
            }
        }, id);
    }

    public List<Transaction> getAll() {
        String sql = "SELECT * FROM Transactions T WHERE order by T.t_id";
        return template.query(sql, new RowMapper<Transaction>() {
            @Override
            public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
//                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
//                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
//                customer.setUser(user);
//                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
//                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
//                shop.setDepartment(department);
                Transaction transaction = (new BeanPropertyRowMapper<>(Transaction.class)).mapRow(rs, rowNum);
//                transaction.setCustomer(customer);
//                transaction.setShop(shop);
                return transaction;
            }
        });
    }

    public List<Transaction> getTransactionBetweenDates(LocalDate d1, LocalDate d2) {
        String sql = "SELECT * FROM Transactions T WHERE T.t_date>=? and T.t_date<=?";
        return template.query(sql, new RowMapper<Transaction>() {
            @Override
            public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
//                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
//                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
//                customer.setUser(user);
//                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
//                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
//                shop.setDepartment(department);
                Transaction transaction = (new BeanPropertyRowMapper<>(Transaction.class)).mapRow(rs, rowNum);
//                transaction.setCustomer(customer);
//                transaction.setShop(shop);
                return transaction;
            }
        }, d1, d2);
    }

    public List<Transaction> getTransactionBetweenDatesInShop(LocalDate d1, LocalDate d2, int shop_id) {
        String sql = "SELECT * FROM Transactions T WHERE T.t_date>=? and T.t_date<=? and T.shop_id=?";
        return template.query(sql, new RowMapper<Transaction>() {
            @Override
            public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
//                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
//                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
//                customer.setUser(user);
//                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
//                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
//                shop.setDepartment(department);
                Transaction transaction = (new BeanPropertyRowMapper<>(Transaction.class)).mapRow(rs, rowNum);
//                transaction.setCustomer(customer);
//                transaction.setShop(shop);
                return transaction;
            }
        }, d1, d2, shop_id);
    }

    public Transaction getIndex() {
        String sql = "SELECT * FROM Transactions T WHERE T.t_id=(SELECT MAX(t_id) FROM Transactions)";
        return template.queryForObject(sql, new RowMapper<Transaction>() {
            @Override
            public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
                Transaction transaction = (new BeanPropertyRowMapper<>(Transaction.class)).mapRow(rs, rowNum);
                return transaction;
            }
        });
    }
}
