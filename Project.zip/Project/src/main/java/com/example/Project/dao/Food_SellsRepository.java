package com.example.Project.dao;


import com.example.Project.models.Department;
import com.example.Project.models.Food_Items;
import com.example.Project.models.Food_Sells;
import com.example.Project.models.Shop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Food_SellsRepository {

    @Autowired
    private JdbcTemplate template;


    public void createSells(Food_Sells food_sells) {
        String sql ="INSERT INTO Food_Sells VALUES(?,?,?)";
        template.update(sql,food_sells.getFood_items().getItem_id(),food_sells.getShop().getShop_id(),food_sells.getCost());
    }

    public List<Food_Sells> getItems(int shop_id) {
        String sql="SELECT * FROM Food_Sells fs,Food_Items fi,Shop s WHERE s.shop_id=? and s.shop_id=fs.shop_id and fs.food_id=fi.Item_id";
        return template.query(sql, new RowMapper<Food_Sells>() {
            @Override
            public Food_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Food_Items food_items=(new BeanPropertyRowMapper<>(Food_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Food_Sells food_sells=(new BeanPropertyRowMapper<>(Food_Sells.class)).mapRow(rs,rowNum);
                food_sells.setFood_items(food_items);
                food_sells.setShop(shop);
                return food_sells;
            }
        }, shop_id);
    }
    public Food_Sells getItem(int item_id, int shop_id) {
        String sql="SELECT * FROM Food_Sells fs, Food_Items fi, Shop s WHERE s.shop_id=? and s.shop_id=fs.shop_id and fs.food_id=fi.Item_id and fs.food_id=?";
        return template.queryForObject(sql, new RowMapper<Food_Sells>() {
            @Override
            public Food_Sells mapRow(ResultSet rs, int rowNum) throws SQLException {
                Food_Items food_items=(new BeanPropertyRowMapper<>(Food_Items.class)).mapRow(rs,rowNum);
                Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
                shop.setDepartment(department);
                Food_Sells food_sells=(new BeanPropertyRowMapper<>(Food_Sells.class)).mapRow(rs,rowNum);
                food_sells.setFood_items(food_items);
                food_sells.setShop(shop);
                return food_sells;
            }
        }, new Object[] { shop_id, item_id} );
    }

    public void DeleteItem(int item_id, int shop_id){
        String sql = "DELETE FROM Food_Sells WHERE food_id=? and shop_id=?";
        template.update(sql,item_id,shop_id);
    }

    public void updateFood(Food_Sells food_sells) {
        String sql = "UPDATE Food_Sells SET cost=? WHERE Item_id=?";
        template.update(sql, food_sells.getCost(), food_sells.getFood_items().getItem_id());
    }
}
