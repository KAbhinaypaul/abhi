CREATE TABLE user(
username varchar(20),
Name varchar(60),
email_address varchar(100),
dateofBirth date,
gender enum('Male','Female','Not Specified') ,
address varchar(200),
role enum('Admin','Employee','Customer','Head of Shop'),
password varchar(256),
phone_no varchar(20),
PRIMARY KEY(username)
);

CREATE TABLE Customer(
customer_id int AUTO_INCREMENT ,
username varchar(20),
PRIMARY KEY(customer_id),
FOREIGN KEY(username) REFERENCES user(username) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Department(
dept_name varchar(20) ,
location varchar(100) ,
No_of_shops int,
PRIMARY KEY (dept_name)
);

CREATE TABLE Admin(
Admin_id int AUTO_INCREMENT,
username varchar(20),
PRIMARY KEY(Admin_id),
FOREIGN KEY(username) REFERENCES user(username) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Cloth_Items(
item_id int AUTO_INCREMENT,
size varchar(10),
type varchar(20),
PRIMARY KEY(item_id)
);

CREATE TABLE Shop(
shop_id int AUTO_INCREMENT,
shop_name varchar(40),
dept_name varchar(20),
PRIMARY KEY(shop_id),
FOREIGN KEY(dept_name)REFERENCES Department(dept_name)
);



CREATE TABLE Cloth_Sells(
cloth_id int,
shop_id int,
cost int,
pieces int,
PRIMARY KEY(cloth_id,shop_id),
FOREIGN KEY(cloth_id) REFERENCES Cloth_Items(item_id) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(shop_id) REFERENCES Shop(shop_id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Employee(
emp_id int AUTO_INCREMENT ,
account_number varchar(20) ,
IFSC_code varchar(40),
Branch_name varchar(20),
shop_id int,
username varchar(20),
PRIMARY KEY(emp_id),
FOREIGN KEY(shop_id) REFERENCES Shop(shop_id)ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(username) REFERENCES user(username) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Food_Items(
Item_id int AUTO_INCREMENT,
name varchar(20),
PRIMARY KEY(Item_id)
);

CREATE TABLE Food_Sells(
food_id int,
shop_id int,
cost int,
PRIMARY KEY(food_id, shop_id),
FOREIGN KEY(food_id) REFERENCES Food_Items(Item_id)ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(shop_id) REFERENCES Shop(shop_id)ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Grocery_Items(
item_id int AUTO_INCREMENT,
name varchar(20),
PRIMARY KEY(item_id)
);

CREATE TABLE Grocery_Sells(
item_id int,
shop_id int,
Cost int,
avaliabilty int ,
PRIMARY KEY(item_id,shop_id),
FOREIGN KEY(item_id) REFERENCES Grocery_Items(item_id)ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(shop_id) REFERENCES Shop(shop_id)ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE Head_of_Shop(
emp_id int,
shop_id int,
PRIMARY KEY(shop_id),
FOREIGN KEY(emp_id) REFERENCES Employee(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(shop_id) REFERENCES Shop(shop_id) ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE Movie(
movie_name varchar(20),
p_tickets int ,
g_tickets int ,
s_tickets int,
p_price int,
g_price int ,
s_price int,
screen_id int,
movie_id int AUTO_INCREMENT ,
PRIMARY KEY(movie_id),
FOREIGN KEY(screen_id) REFERENCES Shop(shop_id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Transactions(
t_id int,
customer_id int,
shop_id int,
Bill int,
t_date date,
PRIMARY KEY(t_id)
);