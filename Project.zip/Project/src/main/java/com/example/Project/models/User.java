package com.example.Project.models;


import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Pattern;
import java.sql.Date;
import java.time.LocalDate;

public class User {

    @Getter @Setter
    private String username;

    @Getter @Setter
    private String password;

    @Getter @Setter
    private String name;

    @Getter @Setter
    private String email_address;

    @Getter @Setter
    private LocalDate dateofBirth;

    @Getter @Setter
    private String gender;

    @Getter @Setter
    private String address;

    @Getter @Setter
    private String role;


    @Getter @Setter
    @Pattern(regexp = "^[1-9][0-9]{9}$", message = "must be a valid phone number")
    public String Phone_no;
}
