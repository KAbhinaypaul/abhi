package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

public class Movie {

    @Getter @Setter
    private int movie_id;

    @Getter @Setter
    @NotBlank
    private String movie_name;

    @Getter @Setter
    private int p_tickets;

    @Getter @Setter
    private int g_tickets;

    @Getter @Setter
    private int s_tickets;

    @Getter @Setter
    private int p_price;

    @Getter @Setter
    private int g_price;

    @Getter @Setter
    private int s_price;



    @Getter @Setter
    private Shop shop;


}
