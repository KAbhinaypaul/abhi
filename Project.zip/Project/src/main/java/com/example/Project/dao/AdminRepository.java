package com.example.Project.dao;

import com.example.Project.models.Admin;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class AdminRepository {

    @Autowired
    private JdbcTemplate template;

    public void CreateAdmin(Admin admin) {
        String sql = "INSERT into Admin(username) VALUES(?)";
        template.update(sql, admin.getUser().getUsername());
    }

    public Admin getCustomerByAdminId(int id) {
        String sql = "SELECT * FROM Admin WHERE Admin_id=?";
        return template.queryForObject(sql, new RowMapper<Admin>() {
            @Override
            public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Admin admin = (new BeanPropertyRowMapper<>(Admin.class)).mapRow(rs, rowNum);
                admin.setUser(user);
                return admin;
            }
        }, new Object[] { id });
    }

    public Admin getAdminByUsername(String username) {
        String sql = "SELECT * FROM Admin A,user U WHERE A.username = ? AND A.username=U.user";
        return template.queryForObject(sql, new RowMapper<Admin>() {
            @Override
            public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs,rowNum);
                Admin admin = (new BeanPropertyRowMapper<>(Admin.class)).mapRow(rs, rowNum);
                admin.setUser(user);
                return admin;
            }
        }, new Object [] { username } );
    }

    public List<Admin> getAll() {
        String sql = "SELECT * FROM Admin NATURAL JOIN user";
        return template.query(sql, new RowMapper<Admin>() {
            @Override
            public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs,rowNum);
                Admin admin = (new BeanPropertyRowMapper<>(Admin.class)).mapRow(rs,rowNum);
                admin.setUser(user);
                return admin;
            }
        });
    }

    public void deleteAdmin(int id) {
        String sql = "DELETE FROM Admin WHERE Admin_id=?";
        template.update(sql,id);
    }
}
