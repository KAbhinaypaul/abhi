package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Grocery_Sells {
    @Getter  @Setter
    private Grocery_Items grocery_items;

    @Getter @Setter
    private Shop shop;

    @Getter @Setter
    private int cost;

    @Getter @Setter
    private int availability;


}
