package com.example.Project.controllers;


import com.example.Project.Services.SecurityService;
import com.example.Project.dao.UserRepository;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
@Transactional
public class LoginController {

    @Autowired
    private SecurityService securityService;

    @Autowired
    UserRepository userRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @GetMapping("/user/login")
    public String login(Model model, String error, String logout) {
        if (error != null)
            model.addAttribute("error", "Invalid username or password");

        if (logout != null) {
            SecurityContextHolder.clearContext();
            model.addAttribute("success", "You have been logged out successfully !");
        }
        return "user/login.html";
    }

    @GetMapping("/welcome")
    public String welcome_page() {
        User user = securityService.findLoggedInUser();

        if (user == null)
            return "redirect:/user/login?error";

        if (user.getRole().equals("Admin"))
            return "redirect:/admin/profile";

        else if (user.getRole().equals("Customer"))
            return "redirect:/customer/profile";

        else if (user.getRole().equals("Head of Shop"))
            return "redirect:/head/profile";

        else if (user.getRole().equals("Employee"))
            return "redirect:/employee/profile";

        else
            return "redirect:/user/login?error";

    }

//    @GetMapping("/logout")
//    public String logging_out() {
//        HttpSession session = request.getSession();
//    }

}
