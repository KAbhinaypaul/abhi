package com.example.Project.dao;

import com.example.Project.models.Customer;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class CustomerRepository {

    @Autowired
    private JdbcTemplate template;

    public void CreateCustomer(Customer customer) {
        String sql = "INSERT into Customer(username) VALUES(?)";
        template.update(sql,customer.getUser().getUsername());
    }

    public void createCustomerByUsername(User user) {
        String sql = "INSERT into Customer(username) VALUES(?)";
        template.update(sql,user.getUsername());
    }
    public Customer getCustomerByCustomerId(int id) {
        String sql = "SELECT * FROM Customer WHERE customer_id=?";
        return template.queryForObject(sql, new RowMapper<Customer>() {
            @Override
            public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
                customer.setUser(user);
                return customer;
            }
        }, new Object[] { id });
    }

    public Customer getCustomerByUsername(String username) {
        String sql = "SELECT * FROM Customer C,user U WHERE C.username = ? and C.username = U.username";
        return template.queryForObject(sql, new RowMapper<Customer>() {
            @Override
            public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs,rowNum);
                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
                customer.setUser(user);
                return customer;
            }
        }, new Object [] { username } );
    }

    public List<Customer> getAll() {
        String sql = "SELECT * FROM Customer NATURAL JOIN user";
        return template.query(sql, new RowMapper<Customer>() {
            @Override
            public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs,rowNum);
                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs,rowNum);
                customer.setUser(user);
                return customer;
            }
        });
    }

    public Customer getCustomer(User user) {
        String sql="SELECT * FROM Customer WHERE username=?";
        return template.queryForObject(sql,new BeanPropertyRowMapper<>(Customer.class), new Object[] { user });
    }

    public void updateCustomer(Customer customer) {
        String sql = "UPDATE Customer SET username=? WHERE customer_id=?";
        template.update(sql,customer.getUser().getUsername(),customer.getCustomer_id());
    }

    public Customer getCustomerById(int id){
        String sql = "SELECT * FROM Customer C, user U WHERE C.customer_id=? and C.username=U.username";
        return template.queryForObject(sql, new RowMapper<Customer>() {
            @Override
            public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Customer customer = (new BeanPropertyRowMapper<>(Customer.class)).mapRow(rs, rowNum);
                customer.setUser(user);
                return customer;
            }
        },new Object[] { id });
    }
}
