package com.example.Project.dao;

import com.example.Project.models.Customer;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public class UserRepository {

    @Autowired
    private JdbcTemplate template;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public void CreateUser(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        String sql = "INSERT INTO user(username,password,Name,email_address,dateofBirth,gender,address,role,phone_no) VALUES(?,?,?,?,?,?,?,?,?)";
        template.update(sql,user.getUsername(),user.getPassword(),user.getName(),user.getEmail_address(),user.getDateofBirth(),user.getGender(),user.getAddress(),user.getRole(),user.getPhone_no());
    }

    public User getUser(String username) {
        String sql = "SELECT * FROM user WHERE username= ? ";
        return template.queryForObject(sql,new BeanPropertyRowMapper<>(User.class), new Object[] { username });
    }

    public void updateUser(User user) {
        String sql = "UPDATE user SET role=?,Name=?,email_address=?,dateofBirth=?,gender=?,address=?,password=?,phone_no=? WHERE username=?";
        template.update(sql,user.getRole(),user.getName(),user.getEmail_address(),user.getDateofBirth(),user.getGender(),user.getAddress(),user.getPassword(),user.getPhone_no(),user.getUsername());
    }

    public void changePassword(String username, String password) {
        String passwordHash = bCryptPasswordEncoder.encode(password);
        String sql="UPDATE user SET password = ? WHERE username = ?";
        template.update(sql,passwordHash,username);
    }

    public void deleteUser(String username) {
        String sql = "DELETE FROM user WHERE username=?";
        template.update(sql,username);
    }

}
