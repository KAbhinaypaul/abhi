package com.example.Project.dao;

import com.example.Project.models.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DepartmentRepository {

    @Autowired
    private JdbcTemplate template;

    public void createDepartment(Department department) {
        String sql = "INSERT INTO Department values(?,?,?)";
        template.update(sql,department.getDeptName(),department.getLocation(),department.getNo_of_shops());
    }

    public void updateDepartment(Department department) {
        String sql = "UPDATE Department SET location=?,No_of_shops=? WHERE dept_name=?";
        template.update(sql,department.getLocation(),department.getNo_of_shops(),department.getDeptName());
    }

    public void deleteDepartment(String department) {
        String sql = "DELETE FROM Department WHERE dept_name=?";
        template.update(sql,department);
    }

    public List<Department> getAll() {
        String sql = "SELECT * FROM Department";
        return template.query(sql, new BeanPropertyRowMapper<>(Department.class));
    }

    public Department getDepartment(String department) {
        String sql = "SELECT * FROM Department WHERE dept_name = ?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<>(Department.class), new Object[] { department });
    }

//    public Department getShops(String s) {
//        String sql = "SELECT * FROM Department WHERE dept_name=?";
//        return template.queryForObject(sql, new BeanPropertyRowMapper<>(Department.class), new Object[] { s });
//    }
}
