package com.example.Project.controllers;
import javax.validation.Valid;

import com.example.Project.Services.SecurityService;
import com.example.Project.dao.*;
import com.example.Project.models.*;
import lombok.Getter;
import lombok.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.Callable;

@Controller
@Transactional
public class CustomerController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private Food_SellsRepository food_sellsRepository;

    @Autowired
    private Grocery_SellsRepository grocery_sellsRepository;

    @Autowired
    private  Cloth_SellsRepository cloth_sellsRepository;



    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private TransactionRepository transactionRepository;



    @GetMapping("/customer/profile")
    public String get_Profile(Model model) {
        User user = securityService.findLoggedInUser();
        User user1 =userRepository.getUser(user.getUsername());
        Customer customer = customerRepository.getCustomerByUsername(user1.getUsername());
        model.addAttribute("user",user1);
        List<Transaction> transactions = transactionRepository.getTransactionByCustomerId(customer.getCustomer_id());
        model.addAttribute("transactions", transactions);
        return "customer/profile.html";
    }

    @GetMapping("/customer/food")
    public String food_shops(Model model) {
        List<Shop> shops = shopRepository.getFoodShops();
        model.addAttribute("shops",shops);
        return "customer/food.html";
    }

    @GetMapping("/customer/food/{shop_id}")
    public String shop_food(@PathVariable("shop_id") int shop_id, Model model) {
        List<Food_Sells> food_sells=food_sellsRepository.getItems(shop_id);
        model.addAttribute("food_sells",food_sells);
        return "customer/fooditems.html";
    }

    @GetMapping("/customer/grocery")
    public String grocery_shops(Model model) {
        List<Shop> shops = shopRepository.getGroceryShops();
        model.addAttribute("shops",shops);
        return "customer/grocery.html";
    }

    @GetMapping("/customer/grocery/{shop_id}")
    public String shop_grocery(@PathVariable("shop_id") int shop_id, Model model) {
        List<Grocery_Sells> grocery_sells=grocery_sellsRepository.getItems(shop_id);
        model.addAttribute("grocery_sells", grocery_sells);
        return "customer/groceryitems.html";
    }

    @GetMapping("/customer/cloth")
    public String Cloth_shops(Model model) {
        List<Shop> shops = shopRepository.getClothShops();
        model.addAttribute("shops",shops);
        return "customer/cloth.html";
    }

    @GetMapping("/customer/cloth/{shop_id}")
    public String shop_cloth(@PathVariable("shop_id") int shop_id, Model model) {
        List<Cloth_Sells> cloth_sells=cloth_sellsRepository.getItems(shop_id);
        model.addAttribute("cloth_sells",cloth_sells);
        return "customer/clothitems.html";
    }

    @GetMapping("/customer/movie")
    public  String movie_shops(Model model){
        List<Movie> movies=movieRepository.getMovies();

        model.addAttribute("movies", movies);
        return "customer/movie.html";
    }
//    @GetMapping("/customer/movie/{shop_id}")
//    public String shop_movie(@PathVariable("shop_id") int shop_id, Model model) {
//        List<Movie> movie=movieRepository.getItems(shop_id);
//        model.addAttribute("movie", movie);
//        return "customer/movie.html";
//    }
//@GetMapping("customer/employee")
//public String get_employee(Model model) {
//    User user1 = securityService.findLoggedInUser();
//    Movie movie = movieRepository.getItems();
//    List<Employee> employeeList = employeeRepository.getEmployeesbyShopid(employee.getShop().getShop_id());
//    model.addAttribute("employees", employeeList);
//    return "head/employee.html";
//}

    @GetMapping("/customer/settings")
    public String profile_settings(Model model) {
        User user=new User();
        User user1 = securityService.findLoggedInUser();
        User user2 = userRepository.getUser(user1.getUsername());
        model.addAttribute("user",user);
        model.addAttribute("default", user2);
        return "customer/settings.html";
    }

    @PostMapping("/customer/settings")
    public String profile_update(@ModelAttribute("user") User user, @RequestParam(name="date") String s) {
        User user1 = securityService.findLoggedInUser();
        user.setPassword(user1.getPassword());
        user.setRole(user1.getRole());
        user.setUsername(user1.getUsername());
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.updateUser(user);
        return "redirect:/customer/profile";
    }
}
