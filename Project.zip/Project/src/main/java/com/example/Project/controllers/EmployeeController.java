package com.example.Project.controllers;

import com.example.Project.Services.SecurityService;
import com.example.Project.dao.*;
import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.javatuples.Triplet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


@Controller
@Transactional

public class EmployeeController {

    @Autowired
    private SecurityService securityService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private UserRepository userRepository;


    @Autowired
    private  Food_SellsRepository food_sellsRepository;

    @Autowired
    private Cloth_SellsRepository cloth_sellsRepository;

    @Autowired
    private Grocery_SellsRepository grocery_sellsRepository;

    @Autowired
    private  Food_ItemsRepository food_itemsRepository;

    @Autowired
    private  Cloth_ItemsRepository cloth_itemsRepository ;

    @Autowired
    private Grocery_ItemsRepository grocery_itemsRepository;

    @Autowired
    private MovieRepository movieRepository;


    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private TransactionRepository transactionRepository;


    public ArrayList<Triplet<Food_Sells,Integer,Integer>> transactionfood = new ArrayList<>();
    public ArrayList<Triplet<Grocery_Sells,Integer,Integer>> transactiongrocery = new ArrayList<>();
    public ArrayList<Triplet<Cloth_Sells,Integer,Integer>> transactioncloth = new ArrayList<>();

    public ArrayList<Triplet<Movie, Integer,Integer>> transactionmovie = new ArrayList<>();



    @GetMapping("/employee/profile")
    public String get_Profile(Model model) {
        User user = securityService.findLoggedInUser();
        User user1 = userRepository.getUser(user.getUsername());
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        model.addAttribute("employee",employee);
        model.addAttribute("user",user1);
        return "employee/profile.html";
    }


    @GetMapping("/employee/settings")
    public String profile_settings(Model model) {
        Employee employee = new Employee();
        User user = new User();
        model.addAttribute("employee", employee);
        model.addAttribute("user", user);
        return "employee/settings.html";
    }

    @PostMapping("/employee/settings")
    public String profile_update(@ModelAttribute("employee") Employee employee, @ModelAttribute("user") User user,@RequestParam(name ="date")String s) {
        User user1 = securityService.findLoggedInUser();
        Employee employee1 = employeeRepository.getEmployeeByUsername(user1.getUsername());
        user.setUsername(user1.getUsername());
        user.setPassword(user1.getPassword());
        user.setRole(user1.getRole());
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.updateUser(user);
        employee.setShop(employee1.getShop());
        employee.setEmp_id(employee1.getEmp_id());
        employee.setUser(user);
        employeeRepository.updateEmployee(employee);
        return "redirect:/employee/profile";
    }
    @GetMapping("/employee/billing")
    public String billing_details(Model model, String error) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if(error!=null)
            model.addAttribute("error","Insufficient Stock");

        if(employee.getShop().getDepartment().getDeptName().equals("Food")) {
            List<Food_Sells> food_sells = food_sellsRepository.getItems(shop_id);
            model.addAttribute("food_sells", food_sells);
            model.addAttribute("transaction", transactionfood);
            return "/employee/foodbilling.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            List<Grocery_Sells> grocery_sells = grocery_sellsRepository.getItems(shop_id);
            model.addAttribute("grocery_sells", grocery_sells);
            model.addAttribute("transaction", transactiongrocery);
            return "employee/grocerybilling.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            List<Cloth_Sells> cloth_sells = cloth_sellsRepository.getItems(shop_id);
            model.addAttribute("cloth_sells", cloth_sells);
            model.addAttribute("transaction", transactioncloth);
            return "employee/clothbilling.html";
        }
        else{
            Movie m = movieRepository.getItem(shop_id);
                model.addAttribute("movie", m);

            return "employee/moviebilling.html";
        }
    }
    @PostMapping("/employee/billing")
    public String pay_bill(@RequestParam(name="item") int item_id, @RequestParam(name="quantity") int number) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if (employee.getShop().getDepartment().getDeptName().equals("Food")) {
            Food_Sells f = food_sellsRepository.getItem(item_id, shop_id);
            Triplet<Food_Sells, Integer, Integer> temp = new Triplet<Food_Sells, Integer, Integer>(f, number, number * f.getCost());
            transactionfood.add(temp);
        } else if (employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            Cloth_Sells c = cloth_sellsRepository.getItem(item_id, shop_id);
            if(c.getPieces()<number)
                return "redirect:/employee/billing?error";
            Triplet<Cloth_Sells, Integer, Integer> temp = new Triplet<Cloth_Sells, Integer, Integer>(c, number, number * c.getCost());
            transactioncloth.add(temp);
        } else if (employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            Grocery_Sells g = grocery_sellsRepository.getItem(item_id, shop_id);
            if(g.getAvailability()<number)
                return "redirect:/employee/billing?error";
            Triplet<Grocery_Sells, Integer, Integer> temp = new Triplet<Grocery_Sells, Integer, Integer>(g, number, number * g.getCost());
            transactiongrocery.add(temp);
        }
        return "redirect:/employee/billing";
    }

    @PostMapping("/employee/moviebill")
    public String movie_bill(@RequestParam(name="pt") int pt, @RequestParam(name="gt") int gt, @RequestParam(name="st") int st,@RequestParam(name="customer") int customer_id) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        Movie m = movieRepository.getItem(shop_id);
        if(m.getP_tickets()<pt || m.getG_tickets()<gt || m.getS_tickets()<st)
            return "redirect:/employee/billing?error";
        m.setP_tickets(m.getP_tickets()-pt);
        m.setG_tickets(m.getG_tickets()-gt);
        m.setS_tickets(m.getS_tickets()-st);
        movieRepository.updateMovie(m);
        Transaction transaction = new Transaction();
        transaction.setBill(m.getP_price()*pt+m.getG_price()*gt+m.getS_price()*st);
        transaction.setShop_id(employee.getShop().getShop_id());
        transaction.setCustomer_id(customerRepository.getCustomerByCustomerId(customer_id).getCustomer_id());
        transaction.setT_date(LocalDate.now());
        transactionRepository.createTransaction(transaction);
        return "redirect:/employee/success_bill";
    }

    @GetMapping("/employee/shop")
    public String shop_details(Model model) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if(employee.getShop().getDepartment().getDeptName().equals("Food")) {
            List<Food_Sells> f = food_sellsRepository.getItems(shop_id);
            model.addAttribute("f", f);
            return "employee/food.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            List<Grocery_Sells> g = grocery_sellsRepository.getItems(shop_id);
            model.addAttribute("g", g);
            return "employee/grocery.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            List<Cloth_Sells> c = cloth_sellsRepository.getItems(shop_id);
            model.addAttribute("c", c);
            return "employee/cloth.html";
        }
        else{
            Movie m = movieRepository.getItem(shop_id);
            model.addAttribute("m" , m);
            return "employee/movie.html";
        }
    }

    @PostMapping("/employee/transaction")
    public String transaction(@RequestParam(name="customer") int customer_id){
        int total_amount = 0;
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        Customer customer = customerRepository.getCustomerById(customer_id);
        Transaction transaction = new Transaction();
        transaction.setT_date(LocalDate.now());
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactionfood.size();i++) {
                total_amount += transactionfood.get(i).getValue2();
            }
            transaction.setBill(total_amount);
//            transaction.setT_date(LocalDate.now());
            transactionRepository.createTransaction(transaction);
            transactionfood.clear();
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactiongrocery.size();i++) {
                total_amount += transactiongrocery.get(i).getValue2();
            }
            transaction.setBill(total_amount);
            transactionRepository.createTransaction(transaction);
            for(int i=0;i<transactiongrocery.size();i++) {
                Grocery_Sells g = new Grocery_Sells();
                g.setShop(transactiongrocery.get(i).getValue0().getShop());
                g.setGrocery_items(transactiongrocery.get(i).getValue0().getGrocery_items());
                g.setAvailability(transactiongrocery.get(i).getValue0().getAvailability()-transactiongrocery.get(i).getValue1());
                grocery_sellsRepository.updateGrocery(g);
            }
            transactiongrocery.clear();
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactioncloth.size();i++) {
                total_amount += transactioncloth.get(i).getValue2();
            }
            transaction.setBill(total_amount);
            transactionRepository.createTransaction(transaction);
            for(int i=0;i<transactioncloth.size();i++) {
                Cloth_Sells g = new Cloth_Sells();
                g.setShop(transactioncloth.get(i).getValue0().getShop());
                g.setCloth_items(transactioncloth.get(i).getValue0().getCloth_items());
                g.setPieces(transactioncloth.get(i).getValue0().getPieces()-transactioncloth.get(i).getValue1());
                cloth_sellsRepository.updateCloth(g);
            }
            transactioncloth.clear();
        }
        else{

        }
        return "redirect:/employee/success_bill";
    }

    @GetMapping("/employee/fail_bill")
    public String failure_bill(){
        return "employee/fail_bill.html";
    }

    @GetMapping("/employee/success_bill")
    public String successful_bill(Model model) {
        Transaction transaction=new Transaction();
        transaction = transactionRepository.getIndex();
        model.addAttribute("transactions", transaction);
        return "employee/success_bill.html";
    }

    @GetMapping("/employee/billing/{bill_id}")
    public String remove_bill(@PathVariable("bill_id") int id) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            transactionfood.remove(id);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")){
            transactioncloth.remove(id);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            transactiongrocery.remove(id);
        }
        return "redirect:/employee/billing";
    }


}
