package com.example.Project.dao;


import com.example.Project.models.Food_Items;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class Food_ItemsRepository {

    @Autowired
    private JdbcTemplate template;

    public void createItem(Food_Items food_items) {
        String sql="INSERT INTO Food_Items(name) VALUES(?)";
        template.update(sql,food_items.getName());
    }

    public List<Food_Items> getAll() {
        String sql = "SELECT * FROM Food_Items";
        return template.query(sql, new RowMapper<Food_Items>() {
            @Override
            public Food_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Food_Items food_items = (new BeanPropertyRowMapper<>(Food_Items.class)).mapRow(rs, rowNum);
                return food_items;
            }
        });
    }

    public Food_Items getItem(int id) {
        String sql="SELECT * FROM Food_Items WHERE Item_id=?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<>(Food_Items.class), new Object[] { id });
    }

    public List<Food_Items> getAllNotFromShop(int id) {
        String sql ="(SELECT * FROM Food_Items fi) EXCEPT (SELECT fi.Item_id,fi.name FROM Food_Items fi, Food_Sells fs, Shop S WHERE fi.Item_id=fs.food_id and S.shop_id=fs.shop_id and S.shop_id=?)";
        return template.query(sql, new RowMapper<Food_Items>() {
            @Override
            public Food_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Food_Items food_items = (new BeanPropertyRowMapper<>(Food_Items.class)).mapRow(rs, rowNum);
                return food_items;
            }
        },id);
    }

    public Food_Items getIndex() {
        String sql = "SELECT * FROM Food_Items WHERE Item_id=(SELECT MAX(Item_id) FROM Food_Items)";
        return template.queryForObject(sql, new RowMapper<Food_Items>() {
            @Override
            public Food_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Food_Items food_items = (new BeanPropertyRowMapper<>(Food_Items.class)).mapRow(rs, rowNum);
                return food_items;
            }
        });
    }
}
