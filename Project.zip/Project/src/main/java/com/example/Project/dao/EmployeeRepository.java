package com.example.Project.dao;


import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
@Component
public class EmployeeRepository {

    @Autowired
    private JdbcTemplate template;

    public void createEmployee(Employee employee) {
        String sql = "INSERT INTO Employee(account_number,IFSC_code,Branch_name,shop_id,username) VALUES(?,?,?,?,?)";
        template.update(sql,employee.getAccount_Number(), employee.getIFSC_code(), employee.getBranch_name(), employee.getShop().getShop_id(), employee.getUser().getUsername());
    }


    public void updateEmployee(Employee employee) {
        String sql = "UPDATE Employee SET account_number=?,IFSC_code=?,Branch_name=? WHERE emp_id=?";
        template.update(sql, employee.getAccount_Number(), employee.getIFSC_code(), employee.getBranch_name(), employee.getEmp_id());
    }

    public void deleteEmployee(int id) {
        String sql = "DELETE FROM Employee WHERE emp_id=?";
        template.update(sql, id);
    }

    public Employee getEmployeeByUsername(String username) {
        String sql="SELECT * FROM Employee E, Shop S, user U WHERE E.username=U.username and U.username=? and S.shop_id=E.shop_id";
        return template.queryForObject(sql, new RowMapper<Employee>() {
            @Override
            public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Employee employee = (new BeanPropertyRowMapper<>(Employee.class)).mapRow(rs, rowNum);
                employee.setUser(user);
                employee.setShop(shop);
                return employee;
            }
        }, new Object[] { username });
    }

    public List<Employee> getEmployeesbyShopid(int shop_id) {
        String sql = "SELECT * FROM Employee E,user U, Shop S WHERE E.shop_id = ? and E.username=U.username and E.shop_id= S.shop_id";
        return template.query(sql, new RowMapper<Employee>() {
            @Override
            public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                Employee employee = (new BeanPropertyRowMapper<>(Employee.class)).mapRow(rs, rowNum);
                employee.setShop(shop);
                employee.setUser(user);
                return employee;
            }
        }, shop_id);
    }

    public Employee getEmployeeById(int id) {
        String sql = "SELECT * FROM Employee E, user U, Shop S WHERE E.Emp_id=? and E.username = U.username and E.shop_id = S.shop_id";
        return template.queryForObject(sql, new RowMapper<Employee>() {
            @Override
            public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = (new BeanPropertyRowMapper<>(User.class)).mapRow(rs, rowNum);
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                Employee employee = (new BeanPropertyRowMapper<>(Employee.class)).mapRow(rs, rowNum);
                employee.setUser(user);
                employee.setShop(shop);
                return employee;
            }
        }, new Object[] { id });
    }
}

