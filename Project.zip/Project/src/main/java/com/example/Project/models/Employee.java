package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Employee {

    @Getter @Setter
    private String Account_Number;

    @Getter @Setter
    private String IFSC_code;

    @Getter @Setter
    private String branch_name;

    @Getter @Setter
    private Shop shop;

    @Getter @Setter
    private int Emp_id;

    @Getter @Setter
    private User user;

}
