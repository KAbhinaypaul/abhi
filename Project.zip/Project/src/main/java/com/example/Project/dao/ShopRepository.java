package com.example.Project.dao;

import com.example.Project.models.Department;
import com.example.Project.models.Shop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


@Repository
public class ShopRepository {

  @Autowired
  private JdbcTemplate template;

  public void CreateShop(Shop shop){
      String sql="INSERT INTO Shop(shop_name,dept_name) values(?,?)";
       template.update(sql,shop.getShop_name(),shop.getDepartment().getDeptName());

  }

  public void UpdateShop(Shop shop){
      String sql="UPDATE Shop SET shop_name=?, department = ? where shop_id=?";
      template.update(sql,shop.getShop_name(),shop.getDepartment(),shop.getShop_id());
  }

  public void DeleteShop(int id){
      String sql="DELETE FROM Shop where Shop_id=?";
      template.update(sql,id);
  }

  public Shop getShop(int shop_id) {
      String sql = "SELECT * FROM Shop S, Department D WHERE shop_id=? and S.dept_name=D.dept_name";
      return template.queryForObject(sql, new RowMapper<Shop>() {
          @Override
          public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
              Department department=(new BeanPropertyRowMapper<>(Department.class)).mapRow(rs,rowNum);
              Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs,rowNum);
              shop.setDepartment(department);
              return shop;
          }
      }, new Object[] { shop_id });
  }
  public List<Shop> getFoodShops() {
      String sql="SELECT * FROM Shop WHERE dept_name='Food'";
      return template.query(sql, new RowMapper<Shop>() {
          @Override
          public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
              Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
              return shop;
          }
      });
  }

  public List<Shop> getAll(){
      String sql="SELECT * FROM Shop";
      return template.query(sql, new RowMapper<Shop>() {
          @Override
          public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
              Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
              return shop;
          }
      });
  }

    public List<Shop> getGroceryShops() {
        String sql="SELECT * FROM Shop WHERE dept_name='Grocery'";
        return template.query(sql, new RowMapper<Shop>() {
            @Override
            public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                return shop;
            }
        });
    }

    public List<Shop> getClothShops() {
        String sql="SELECT * FROM Shop WHERE dept_name='Clothes'";
        return template.query(sql, new RowMapper<Shop>() {
            @Override
            public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                return shop;
            }
        });
    }

    public List<Shop> getMovieShops() {
        String sql="SELECT * FROM Shop WHERE dept_name='Movies'";
        return template.query(sql, new RowMapper<Shop>() {
            @Override
            public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
                Shop shop=(new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                return shop;
            }
        });
    }

    public Shop getIndex() {
      String sql = "SELECT * FROM Shop WHERE shop_id=(SELECT MAX(shop_id) FROM Shop)";
      return template.queryForObject(sql, new RowMapper<Shop>() {
          @Override
          public Shop mapRow(ResultSet rs, int rowNum) throws SQLException {
              Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
              Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
              shop.setDepartment(department);
              return shop;
          }
      });
    }
}
