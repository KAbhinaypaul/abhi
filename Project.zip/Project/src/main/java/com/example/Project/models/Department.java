package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Department {

    @Getter @Setter
    private String DeptName;

    @Getter @Setter
    private String location;

    @Getter @Setter
    private int No_of_shops;
}
