package com.example.Project.controllers;


import com.example.Project.Services.SecurityService;
import com.example.Project.dao.CustomerRepository;
import com.example.Project.dao.UserRepository;
import com.example.Project.models.Customer;
import com.example.Project.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserCache;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@Controller
@Transactional
public class HomeController {


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @GetMapping("/")
    public String home_page() {
        return "home.html";
    }

    @GetMapping("/signup")
    public String signing_up(Model model) {
        User user=new User();
        model.addAttribute("user", user);
        return "signup.html";

    }

    @PostMapping("/signup")
    public String signed_up(@ModelAttribute("user") User user,@RequestParam(name="date") String s) {
        user.setRole("Customer");
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.CreateUser(user);
        customerRepository.createCustomerByUsername(user);
        return "redirect:/user/login";
    }

    @GetMapping("/change-password")
    public String update_password() {
        User user1 = securityService.findLoggedInUser();
        if(user1.getRole().equals("Admin"))
            return "admin/password-update.html";
        else if(user1.getRole().equals("Customer"))
            return "customer/password-update.html";
        else if(user1.getRole().equals("Head of Shop"))
            return "head/password-update.html";
        else
            return "employee/password-update.html";
    }

    @PostMapping("/change-password")
    public String updated_password(@RequestParam(name="old_password") String p1, @RequestParam(name="new_password") String p2) {
        User user1 = securityService.findLoggedInUser();
//        String password = bCryptPasswordEncoder.encode(p1);
        if(user1.getUsername().equals(p1)){
            userRepository.changePassword(user1.getUsername(),p2);
            if(user1.getRole().equals("Admin"))
                return "redirect:/admin/profile";
            else if(user1.getRole().equals("Head of Shop"))
                return "redirect:/head/profile";
            else if(user1.getRole().equals("Employee"))
                return "redirect:/employee/profile";
            else
                return "redirect:/customer/profile";
        }
        else
            return "redirect:/change-password";
    }
}
