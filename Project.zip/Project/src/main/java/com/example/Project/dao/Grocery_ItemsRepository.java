package com.example.Project.dao;

import com.example.Project.models.Food_Items;
import com.example.Project.models.Grocery_Items;
import com.example.Project.models.Grocery_Sells;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository

public class Grocery_ItemsRepository {

    @Autowired
    private JdbcTemplate template;
    public Grocery_Items getItem(int id) {
        String sql="SELECT * FROM Grocery_Items WHERE item_id=?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<>(Grocery_Items.class), new Object[] { id });
    }

    public void createGrocery_Item(Grocery_Items grocery_items) {
        String sql = "INSERT INTO Grocery_Items(name) VALUES(?)";
        template.update(sql,grocery_items.getName());
    }

    public List<Grocery_Items> getAllNotFromShop(int id) {
        String sql ="(SELECT * FROM Grocery_Items gi) EXCEPT (SELECT gi.item_id,gi.name FROM Grocery_Items gi, Grocery_Sells gs, Shop S WHERE gi.item_id=gs.item_id and S.shop_id=gs.shop_id and S.shop_id=?)";
        return template.query(sql, new RowMapper<Grocery_Items>() {
            @Override
            public Grocery_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Grocery_Items grocery_items = (new BeanPropertyRowMapper<>(Grocery_Items.class)).mapRow(rs, rowNum);
                return grocery_items;
            }
        },id);
    }


    public void deleteGrocery_Item(int id) {
        String sql = "DELETE FROM Grocery_Items where Item_id=?";
        template.update(sql,id);
    }
    public Grocery_Items getIndex() {
        String sql = "SELECT * FROM Grocery_Items WHERE Item_id=(SELECT MAX(Item_id) FROM Grocery_Items)";
        return template.queryForObject(sql, new RowMapper<Grocery_Items>() {
            @Override
            public Grocery_Items mapRow(ResultSet rs, int rowNum) throws SQLException {
                Grocery_Items grocery_items = (new BeanPropertyRowMapper<>(Grocery_Items.class)).mapRow(rs, rowNum);
                return grocery_items;
            }
        });
    }
}
