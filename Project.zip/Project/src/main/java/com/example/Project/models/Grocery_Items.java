package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Grocery_Items {

    @Getter @Setter
    private String name;

    @Getter @Setter
    private int Item_id;



}
