package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Food_Items {
    @Getter @Setter
    private int Item_id;

    @Getter @Setter
    private String name;

}
