package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class Transaction {

    @Getter @Setter
    private int t_id;

    @Getter @Setter
    private int customer_id;

    @Getter @Setter
    private  int shop_id;


    @Getter @Setter
    private int Bill;

    @Getter @Setter
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate t_date;

//    @Override
//    public String toString() {
//        return "Transaction{" +
//                "t_id=" + t_id +
//                ", customer=" + customer.getCustomer_id()+
//                ", shop=" + shop.getShop_id() +
//                ", Amount=" + Bill +
//                '}';
//    }
}
