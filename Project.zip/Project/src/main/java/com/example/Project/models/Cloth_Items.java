package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Cloth_Items {

    @Getter @Setter
    private int item_id;

    @Getter @Setter
    private String size;

    @Getter @Setter
    private String type;

}
