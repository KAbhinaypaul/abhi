package com.example.Project.controllers;


import com.example.Project.dao.*;
import com.example.Project.models.*;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.sql.Date;
import java.time.LocalDate;

@Controller
@Transactional
public class Demo {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private Food_ItemsRepository food_itemsRepository;

    @Autowired
    private HOSRepository hosRepository;

    @GetMapping("/fuck")
    public String createitem(Model model) {
        Food_Items food_items=new Food_Items();
        food_items.setItem_id(50);
        model.addAttribute("item", food_items);
        return "customer/rough.html";
    }

    @PostMapping("/fuck")
    public String itemproduced(@ModelAttribute("item") Food_Items food_items) {
        food_itemsRepository.createItem(food_items);
        return "home.html";
    }


    @GetMapping("/abhi")
    public String createUser(Model model) {
        User user = new User();
        user.setUsername("devapaul");
        user.setPassword("Manemma@1996");
        user.setName("Banavath Mourya Naik");
        user.setEmail_address("bmnaik@gmail.com");
        user.setDateofBirth(LocalDate.of(2003,11,23));
        user.setGender("Male");
        user.setAddress("Bengalore");
        user.setRole("Admin");
        userRepository.CreateUser(user);
//        Employee employee= new Employee();
//        employee.setUser(user);
//        Shop shop = new Shop();
//        Department department=new Department();
//        department.setDeptName("Movies");
//        department.setLocation("3rd Floor");
//        department.setNo_of_shops(0);
//        shop.setDepartment(department);
//        shop.setShop_id(6);
//        shop.setShop_name("DanarajGiri");
//        employee.setShop(shop);
//        employee.setEmp_id(1);
        Admin admin = new Admin();
        admin.setUser(user);
        adminRepository.CreateAdmin(admin);
        return "home.html";
    }
//    @GetMapping("/abhi")
//    public String deleteuser(Model model){
//        userRepository.deleteUser("dassu");
//        return "demo.html";
//    }
//
//    @GetMapping("/abhi")
//    public String rough(Model model) {
//        Employee e = employeeRepository.getEmployeeByUsername("bmourya");
//        model.addAttribute("e", e);
//        return "demo.html";
//    }
}
