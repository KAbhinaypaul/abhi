package com.example.Project.models;

import lombok.Getter;
import lombok.Setter;

public class Admin {

    @Getter @Setter
    private int Admin_id;

    @Getter @Setter
    private User user;

}
