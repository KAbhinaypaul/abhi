package com.example.Project.dao;

import com.example.Project.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository

public class MovieRepository {
    @Autowired
    private JdbcTemplate template;


    public Movie getItem(int screen_id) {
        String sql="SELECT * FROM Movie m,Shop s WHERE s.shop_id=? and s.shop_id=m.screen_id ";
        return template.queryForObject(sql, new RowMapper<Movie>() {
            @Override
            public Movie mapRow(ResultSet rs, int rowNum) throws SQLException {
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                Movie movie = (new BeanPropertyRowMapper<>(Movie.class)).mapRow(rs, rowNum);
                movie.setShop(shop);
                return movie;
            }
        }, screen_id);
    }

    public List<Movie> getMovies() {
        String sql = "SELECT * FROM Movie m, Shop s WHERE m.screen_id=s.shop_id";
        return template.query(sql, new RowMapper<Movie>() {
            @Override
            public Movie mapRow(ResultSet rs, int rowNum) throws SQLException {
                Department department = (new BeanPropertyRowMapper<>(Department.class)).mapRow(rs, rowNum);
                Shop shop = (new BeanPropertyRowMapper<>(Shop.class)).mapRow(rs, rowNum);
                shop.setDepartment(department);
                Movie movie = (new BeanPropertyRowMapper<>(Movie.class)).mapRow(rs, rowNum);
                movie.setShop(shop);
                return movie;
            }
        });
    }

    public void updateMovie(Movie movie) {
        String sql = "UPDATE Movie SET p_tickets=?, g_tickets=?, s_tickets=? WHERE movie_id=?";
        template.update(sql, movie.getP_tickets(), movie.getG_tickets(), movie.getS_tickets(), movie.getMovie_id());
    }

    public void deleteMovie(int id){
        String sql = "DELETE FROM Movie WHERE screen_id=?";
        template.update(sql, id);
    }

    public void createMovie(Movie movie) {
        String sql = "INSERT INTO Movie(movie_name,p_tickets,g_tickets,s_tickets,p_price,g_price,s_price,screen_id) VALUES(?,?,?,?,?,?,?,?)";
        template.update(sql, movie.getMovie_name(), movie.getP_tickets(), movie.getG_tickets(), movie.getS_tickets(), movie.getP_price(), movie.getG_price(), movie.getS_price(), movie.getShop().getShop_id());

    }
}
