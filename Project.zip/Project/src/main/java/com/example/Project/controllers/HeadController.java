package com.example.Project.controllers;


import com.example.Project.Services.SecurityService;
import com.example.Project.dao.*;
import com.example.Project.models.*;
import org.javatuples.Triplet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.javatuples.Triplet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@Transactional
public class HeadController {

    @Autowired
    private SecurityService securityService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private Food_SellsRepository food_sellsRepository;

    @Autowired
    private Cloth_ItemsRepository cloth_itemsRepository;

    @Autowired
    private Cloth_SellsRepository cloth_sellsRepository;

    @Autowired
    private Food_ItemsRepository food_itemsRepository;

    @Autowired
    private Grocery_ItemsRepository grocery_itemsRepository;

    @Autowired
    private  Grocery_SellsRepository grocery_sellsRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private MovieRepository movieRepository;

    public ArrayList<Triplet<Food_Sells,Integer,Integer>> transactionfood = new ArrayList<>();
    public ArrayList<Triplet<Grocery_Sells,Integer,Integer>> transactiongrocery = new ArrayList<>();
    public ArrayList<Triplet<Cloth_Sells,Integer,Integer>> transactioncloth = new ArrayList<>();

    public ArrayList<Triplet<Movie,Integer,Integer>> transactionmovie = new ArrayList<>();

    public LocalDate d1 = LocalDate.of(0000,01,01);
    public LocalDate d2 = LocalDate.now();

    int shop_id=-1;

    @GetMapping("/head/profile")
    public String get_Profile(Model model) {
        User user = securityService.findLoggedInUser();
        User user1 = userRepository.getUser(user.getUsername());
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        model.addAttribute("employee",employee);
        model.addAttribute("user",user1);
        return "head/profile.html";
    }



    @GetMapping("/head/settings")
    public String profile_settings(Model model) {
        Employee employee = new Employee();
        User user = new User();
        model.addAttribute("employee", employee);
        model.addAttribute("user", user);
        return "head/settings.html";
    }

    @PostMapping("/head/settings")
    public String profile_update(@ModelAttribute("employee") Employee employee, @ModelAttribute("user") User user,@RequestParam(name="date")String s) {
        User user1 = securityService.findLoggedInUser();
        Employee employee1 = employeeRepository.getEmployeeByUsername(user1.getUsername());
        user.setUsername(user1.getUsername());
        user.setPassword(user1.getPassword());
        user.setRole(user1.getRole());
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.updateUser(user);
        employee.setShop(employee1.getShop());
        employee.setEmp_id(employee1.getEmp_id());
        employee.setUser(user);
        employeeRepository.updateEmployee(employee);
        return "redirect:/head/profile";
    }
    @GetMapping("/head/billing")
    public String billing_details(Model model, String error) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if(error!=null) {
            model.addAttribute("error", "Insufficient Stock");
        }

        if(employee.getShop().getDepartment().getDeptName().equals("Food")) {
            List<Food_Sells> food_sells = food_sellsRepository.getItems(shop_id);
            model.addAttribute("food_sells", food_sells);
            model.addAttribute("transaction", transactionfood);
            return "/head/foodbilling.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            List<Grocery_Sells> grocery_sells = grocery_sellsRepository.getItems(shop_id);
            model.addAttribute("grocery_sells", grocery_sells);
            model.addAttribute("transaction", transactiongrocery);
            return "head/grocerybilling.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            List<Cloth_Sells> cloth_sells = cloth_sellsRepository.getItems(shop_id);
            model.addAttribute("cloth_sells", cloth_sells);
            model.addAttribute("transaction", transactioncloth);
            return "head/clothbilling.html";
        }
        else {
            Movie m = movieRepository.getItem(shop_id);
            model.addAttribute("movie", m);

            return "head/moviebilling.html";
        }
    }
    @PostMapping("/head/billing")
    public String pay_bill(@RequestParam(name="item") int item_id, @RequestParam(name="quantity") int number) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            Food_Sells f = food_sellsRepository.getItem(item_id, shop_id);
            Triplet<Food_Sells, Integer, Integer> temp = new Triplet<Food_Sells, Integer, Integer>(f, number, number * f.getCost());
            transactionfood.add(temp);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            Cloth_Sells c = cloth_sellsRepository.getItem(item_id, shop_id);
            if(c.getPieces()<number)
                return "redirect:/head/billing?error";
            Triplet<Cloth_Sells, Integer, Integer> temp = new Triplet<Cloth_Sells, Integer, Integer>(c, number, number * c.getCost());
            transactioncloth.add(temp);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            Grocery_Sells g = grocery_sellsRepository.getItem(item_id, shop_id);
            if(g.getAvailability()<number)
                return "redirect:/head/billing?error";
            Triplet<Grocery_Sells, Integer, Integer> temp = new Triplet<Grocery_Sells, Integer, Integer>(g, number, number * g.getCost());
            transactiongrocery.add(temp);
        }
        return "redirect:/head/billing";
    }
    @PostMapping("/head/moviebill")
    public String movie_bill(@RequestParam(name="pt") int pt, @RequestParam(name="gt") int gt, @RequestParam(name="st") int st,@RequestParam(name="customer") int customer_id) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        Movie m = movieRepository.getItem(shop_id);
        if(m.getP_tickets()<pt || m.getG_tickets()<gt || m.getS_tickets()<st)
            return "redirect:/head/billing?error";
        m.setP_tickets(m.getP_tickets()-pt);
        m.setG_tickets(m.getG_tickets()-gt);
        m.setS_tickets(m.getS_tickets()-st);
        movieRepository.updateMovie(m);
        Transaction transaction = new Transaction();
        transaction.setBill(m.getP_price()*pt+m.getG_price()*gt+m.getS_price()*st);
        transaction.setShop_id(employee.getShop().getShop_id());
        transaction.setCustomer_id(customerRepository.getCustomerByCustomerId(customer_id).getCustomer_id());
        transaction.setT_date(LocalDate.now());
        transactionRepository.createTransaction(transaction);
        return "redirect:/head/success_bill";
    }

    @GetMapping("/head/shop")
    public String shop_details(Model model) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int shop_id = employee.getShop().getShop_id();
        if(employee.getShop().getDepartment().getDeptName().equals("Food")) {
            List<Food_Sells> f = food_sellsRepository.getItems(shop_id);
            model.addAttribute("f", f);
            return "head/food.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")) {
            List<Grocery_Sells> g = grocery_sellsRepository.getItems(shop_id);
            model.addAttribute("g", g);
            return "head/grocery.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            List<Cloth_Sells> c = cloth_sellsRepository.getItems(shop_id);
            model.addAttribute("c", c);
            return "head/cloth.html";
        }
        else {
            Movie m = movieRepository.getItem(shop_id);
            model.addAttribute("m", m);
            return "head/movie.html";
        }
    }

    @GetMapping("head/employee")
    public String get_employee(Model model) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        List<Employee> employeeList = employeeRepository.getEmployeesbyShopid(employee.getShop().getShop_id());
        model.addAttribute("employees", employeeList);
        return "head/employee.html";
    }
    @GetMapping("/head/addemployee")
    public String add_employee(Model model){
        User user = new User();
        Employee employee = new Employee();
        model.addAttribute("user", user);
        model.addAttribute("employee",employee);
        return "head/add_employee.html";
    }

    @PostMapping("/head/addemployee")
    public String employee_details(@ModelAttribute("user") User user, @ModelAttribute("employee") Employee employee, @RequestParam(name="date") String s) {
        User user1 = securityService.findLoggedInUser();
        Employee employee1 = employeeRepository.getEmployeeByUsername(user1.getUsername());
        employee.setShop(employee1.getShop());
        user.setRole("Employee");
        user.setDateofBirth(LocalDate.parse(s));
        userRepository.CreateUser(user);
        employee.setUser(user);
        employeeRepository.createEmployee(employee);
        return "redirect:/head/employee";
    }

    @GetMapping("/head/remove_employee/{emp_id}")
    public String remove_employee(@PathVariable("emp_id") int id){
        Employee employee = employeeRepository.getEmployeeById(id);
        userRepository.deleteUser(employee.getUser().getUsername());
        return "redirect:/head/employee";
    }

    @PostMapping("/head/transaction")
    public String transaction(@RequestParam(name="customer") int customer_id){
        int total_amount = 0;
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        Customer customer = customerRepository.getCustomerById(customer_id);
        Transaction transaction = new Transaction();
        transaction.setT_date(LocalDate.now());
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactionfood.size();i++) {
                total_amount += transactionfood.get(i).getValue2();
            }
            transaction.setBill(total_amount);
            transactionRepository.createTransaction(transaction);
            transactionfood.clear();
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactiongrocery.size();i++) {
                total_amount += transactiongrocery.get(i).getValue2();
            }
            transaction.setBill(total_amount);
            transactionRepository.createTransaction(transaction);
            for(int i=0;i<transactiongrocery.size();i++) {
                Grocery_Sells g = new Grocery_Sells();
                g.setShop(transactiongrocery.get(i).getValue0().getShop());
                g.setGrocery_items(transactiongrocery.get(i).getValue0().getGrocery_items());
                g.setAvailability(transactiongrocery.get(i).getValue0().getAvailability()-transactiongrocery.get(i).getValue1());
                grocery_sellsRepository.updateGrocery(g);

            }
            transactiongrocery.clear();
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
            transaction.setCustomer_id(customer.getCustomer_id());
            transaction.setShop_id(employee.getShop().getShop_id());
            for(int i=0;i<transactioncloth.size();i++) {
                total_amount += transactioncloth.get(i).getValue2();
            }
            transaction.setBill(total_amount);
            transactionRepository.createTransaction(transaction);
            for(int i=0;i<transactioncloth.size();i++) {
                Cloth_Sells c = new Cloth_Sells();
                c.setShop(transactioncloth.get(i).getValue0().getShop());
                c.setCloth_items(transactioncloth.get(i).getValue0().getCloth_items());
                c.setPieces(transactioncloth.get(i).getValue0().getPieces()-transactioncloth.get(i).getValue1());
                cloth_sellsRepository.updateCloth(c);

            }
            transactioncloth.clear();
        }
        return "redirect:/head/success_bill";
    }

    @GetMapping("/head/fail_bill")
    public String failure_bill(){
        return "head/fail_bill.html";
    }

    @GetMapping("/head/success_bill")
    public String successful_bill(Model model) {

        Transaction transaction = transactionRepository.getIndex();
        model.addAttribute("transactions", transaction);
        return "head/success_bill.html";
    }

    @GetMapping("/head/billing/{bill_id}")
    public String remove_bill(@PathVariable("bill_id") int id) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            transactionfood.remove(id);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")){
            transactioncloth.remove(id);
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            transactiongrocery.remove(id);
        }
        return "redirect:/head/billing";
    }

    @GetMapping("/head/add_item")
    public String new_item(Model model) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            List<Food_Items> f = food_itemsRepository.getAllNotFromShop(employee.getShop().getShop_id());
            model.addAttribute("items", f);
            return "head/add_fooditem.html";
        }
        else if (employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            List<Grocery_Items> g =grocery_itemsRepository.getAllNotFromShop(employee.getShop().getShop_id());
            model.addAttribute("items",g);
            return "head/add_groceryitem.html";
        }
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")){
            List<Cloth_Items> c=cloth_itemsRepository.getAllNotFromShop(employee.getShop().getShop_id());
            model.addAttribute("items",c);
            return "head/add_clothitem.html";
        }
        return "head/shop.html";
    }

    @PostMapping("head/add_fooditem")
    public String new_fooditem(@RequestParam(name="item") String item, @RequestParam(name="name") String name, @RequestParam(name="oldrate") int oldrate, @RequestParam(name="newrate") int newrate){
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        System.out.println(item);
        int id = Integer.parseInt(item);
        System.out.println(id);
//        if(employee.getShop().getDepartment().getDeptName().equals("Food")){
            if(id==0){
                Food_Items food_items = new Food_Items();
                food_items.setName(name);
                food_itemsRepository.createItem(food_items);
                food_items.setItem_id(food_itemsRepository.getIndex().getItem_id());

                Food_Sells food_sells = new Food_Sells();
                food_sells.setShop(employee.getShop());
                food_sells.setFood_items(food_items);
                food_sells.setCost(newrate);
                food_sellsRepository.createSells(food_sells);
            }
            else{
                Food_Sells food_sells = new Food_Sells();
                food_sells.setCost(oldrate);
                food_sells.setFood_items(food_itemsRepository.getItem(id));
                food_sells.setShop(employee.getShop());
                food_sellsRepository.createSells(food_sells);
            }
        return "redirect:/head/shop";
    }

    @PostMapping("/head/add_groceryitem")
    public String item_creation(@RequestParam(name="item") String item, @RequestParam(name="name") String name, @RequestParam(name="oldstock") int availability, @RequestParam(name="newstock") int new_availability ,@RequestParam(name="oldrate") int oldrate,@RequestParam(name="newrate") int newrate){
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int id = Integer.parseInt(item);
//        if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
            if(id==0){
                Grocery_Items grocery_items = new Grocery_Items();
                grocery_items.setName(name);
                grocery_itemsRepository.createGrocery_Item(grocery_items);
                grocery_items.setItem_id(grocery_itemsRepository.getIndex().getItem_id());
                Grocery_Sells grocery_sells = new Grocery_Sells();
                grocery_sells.setShop(employee.getShop());
                grocery_sells.setGrocery_items(grocery_items);
                grocery_sells.setCost(newrate);
                grocery_sells.setAvailability(new_availability);
                grocery_sellsRepository.createSells(grocery_sells);
            }
            else{
                Grocery_Sells grocery_sells = new Grocery_Sells();
                grocery_sells.setCost(oldrate);
                grocery_sells.setGrocery_items(grocery_itemsRepository.getItem(id));
                grocery_sells.setShop(employee.getShop());
                grocery_sells.setAvailability(availability);
                grocery_sellsRepository.createSells(grocery_sells);
            }
//        }
//        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes")) {
//            if(id==0){
//                Cloth_Items cloth_items=new Cloth_Items();
//                cloth_items.setType(name);
//                cloth_itemsRepository.createCloth_Item(cloth_items);
//                cloth_items.setItem_id(cloth_itemsRepository.getIndex().getItem_id());
//                Cloth_Sells cloth_sells=new Cloth_Sells();
//                cloth_sells.setShop(employee.getShop());
//                cloth_sells.setCloth_items(cloth_items);
//                cloth_sells.setCost(newrate);
//                cloth_sells.setPieces(new_availability);
//                cloth_sellsRepository.createSells(cloth_sells);
//            }
//            else {
//                Cloth_Sells cloth_sells=new Cloth_Sells();
//                cloth_sells.setCost(oldrate);
//                cloth_sells.setCloth_items(cloth_itemsRepository.getItem(id));
//                cloth_sells.setShop(employee.getShop());
//                cloth_sells.setPieces(new_availability);
//                cloth_sellsRepository.createSells(cloth_sells);
//            }


//        }

        return "redirect:/head/shop";
    }

    @PostMapping("/head/add_clothitem")
    public String movie_bill(@RequestParam(name="item") String item, @RequestParam(name="type") String type, @RequestParam(name="size") String size, @RequestParam(name="oldrate") int oldrate, @RequestParam(name="newrate") int newrate, @RequestParam(name="oldstock") int oldstock, @RequestParam(name="newstock") int newstock) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        int id = Integer.parseInt(item);
//        if(employee.getShop().getDepartment().getDeptName().equals("Grocery")){
        if(id==0){
            Cloth_Items cloth_items = new Cloth_Items();
            cloth_items.setType(type);
            cloth_items.setSize(size);
            cloth_itemsRepository.createCloth_Item(cloth_items);
//            grocery_itemsRepository.createGrocery_Item(grocery_items);
            cloth_items.setItem_id(cloth_itemsRepository.getIndex().getItem_id());
            Cloth_Sells cloth_sells = new Cloth_Sells();
//            Grocery_Sells grocery_sells = new Grocery_Sells();
            cloth_sells.setShop(employee.getShop());
            cloth_sells.setCloth_items(cloth_items);
            cloth_sells.setCost(newrate);
            cloth_sells.setPieces(newstock);
            cloth_sellsRepository.createSells(cloth_sells);
        }
        else{
            Cloth_Sells cloth_sells = new Cloth_Sells();
            cloth_sells.setCost(oldrate);
            cloth_sells.setCloth_items(cloth_itemsRepository.getItem(id));
            cloth_sells.setShop(employee.getShop());
            cloth_sells.setPieces(oldstock);
            cloth_sellsRepository.createSells(cloth_sells);
        }
        return "redirect:/head/shop";
    }

    @GetMapping("/head/transactions")
    public String transactions(Model model) {
        List<Transaction> transactions;
        User user1 =securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        transactions = transactionRepository.getTransactionBetweenDatesInShop(d1,d2,employee.getShop().getShop_id());
        model.addAttribute("transactions", transactions);
        d1 = LocalDate.of(0000,01,01);
        d2 = LocalDate.now();
//        List<Shop> shops = shopRepository.getAll();
//        model.addAttribute("shops", shops);
        return "head/transactions.html";
    }

    @PostMapping("/head/transactions")
    public String transactionsBetweenDates(@RequestParam("from_date") String a, @RequestParam("to_date") String b){
        if(a!="")
            d1 = LocalDate.parse(a);
        if(b!="")
            d2 = LocalDate.parse(b);
//        shop_id = id;
        return "redirect:/head/transactions";
    }

    @GetMapping("/head/delete_item/{item_id}/{shop_id}")
    public String delete_item(@PathVariable("item_id") int item_id, @PathVariable("shop_id") int shop_id) {
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        if(employee.getShop().getDepartment().getDeptName().equals("Grocery"))
            grocery_sellsRepository.DeleteItem(item_id,shop_id);
        else if(employee.getShop().getDepartment().getDeptName().equals("Food"))
            food_sellsRepository.DeleteItem(item_id,shop_id);
        else if(employee.getShop().getDepartment().getDeptName().equals("Clothes"))
            cloth_sellsRepository.DeleteItem(item_id,shop_id);
        return "redirect:/head/shop";
    }

    @PostMapping("/head/update-cloth/{cloth_id}")
    public String update_cloth(@PathVariable("cloth_id") int id, @RequestParam(name="rate") int rate, @RequestParam(name="stock") int stock) {
        User user = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        Cloth_Sells cloth_sells = cloth_sellsRepository.getItem(id, employee.getShop().getShop_id());
        cloth_sells.setPieces(stock);
        cloth_sells.setCost(rate);
        cloth_sellsRepository.updateCloth(cloth_sells);
        return "redirect:/head/shop";
    }
    @PostMapping("/head/update-food/{food_id}")
    public String update_food(@PathVariable("food_id") int id, @RequestParam(name="rate") int rate) {
        User user = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        Food_Sells food_sells = food_sellsRepository.getItem(id, employee.getShop().getShop_id());
//        food_sells.setPieces(stock);
        food_sells.setCost(rate);
        food_sellsRepository.updateFood(food_sells);
        return "redirect:/head/shop";
    }
    @PostMapping("/head/update-grocery/{grocery_id}")
    public String update_grocery(@PathVariable("grocery_id") int id, @RequestParam(name="rate") int rate, @RequestParam(name="stock") int stock) {
        User user = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        Grocery_Sells grocery_sells = grocery_sellsRepository.getItem(id, employee.getShop().getShop_id());
        grocery_sells.setAvailability(stock);
        grocery_sells.setCost(rate);
        grocery_sellsRepository.updateGrocery(grocery_sells);
        return "redirect:/head/shop";
    }

    @GetMapping("/head/add_movie")
    public String update_movie(Model model){
        User user1 = securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user1.getUsername());
        movieRepository.deleteMovie(employee.getShop().getShop_id());
        Movie movie = new Movie();
        model.addAttribute("movie", movie);
        return "head/add_movie.html";
    }

    @PostMapping("/head/add_movie")
    public String movie_updated(@ModelAttribute("movie") Movie movie) {
        User user=securityService.findLoggedInUser();
        Employee employee = employeeRepository.getEmployeeByUsername(user.getUsername());
        movie.setShop(employee.getShop());
        movieRepository.createMovie(movie);
        return "redirect:/head/shop";
    }
}
